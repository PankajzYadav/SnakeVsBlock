import javafx.scene.control.Label;
public class Labels extends Label {

}
