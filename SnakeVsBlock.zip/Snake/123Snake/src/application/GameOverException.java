package application;

public class GameOverException extends Exception {
}
