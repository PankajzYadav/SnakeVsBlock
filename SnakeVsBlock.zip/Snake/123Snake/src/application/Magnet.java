package application;
import java.time.Duration;

public class Magnet {
	private int value;
	private Duration time;
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public Duration getTime() {
		return time;
	}
	public void setTime(Duration time) {
		this.time = time;
	}
	public void initializeMagnet() {
		
	}
	public void collideMagnet() {
		
	}
}
